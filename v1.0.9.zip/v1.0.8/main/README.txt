Olá, Este é o codigo responsável pelo funcionamento do Robô Al B. Gorithm da equipe Sesi Hortobots da Unidade CE Sesi 437 - Hortolândia.
Ele foi desenvolvido com uma grande tragetoria por cerca de 2 meses. foi aprimorado diversas vezes e isto é prova de seu aperfeiçoamento.

O código funciona de maneira simples. O programa principal é executado em python, e para que o robô possa executar suas tarefas físicas, 
commandos são transmitidos do python para o arduino por meio da porta de conexão Serial. Dessa forma, conseguimos atingir uma comunicação 
harmoniosa entre o computador e o microcontrolador, nos permitindo utilizar, mesclar e combar funcionalidades e tecnologias que não poderiam
ser utilizadas de maneira individual, como a locomoção do robô, Tracking de rosto e 'perseguição' de alvo.

Atualmente o Código se encontra em sua versão 5.1
