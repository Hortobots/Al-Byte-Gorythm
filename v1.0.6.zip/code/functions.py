import pygame
import asyncio
import multiprocessing

from main import main_loop

#tocar um som
def playSound(file):
    pygame.mixer.init()
    pygame.mixer.music.load(file)
    pygame.mixer.music.play()

#parar todos os sons
def stopAllSounds():
    pygame.mixer.music.stop()   

#espera uma quantidade de dedos levantadas
async def waitToFingersUp(target_fingers, shared_fingers, stop_event):
    print(f"Aguardando {target_fingers} dedos levantados...")
    while not stop_event.is_set():
        if shared_fingers.value == target_fingers:
            print(f"{target_fingers} dedos detectados! Continuando execução...")
            return
        await asyncio.sleep(0.1)  # Pequeno delay para evitar sobrecarga da CPU

def start_multi_process():
    manager = multiprocessing.Manager()
    window_ready = manager.Event()
    stop_event = manager.Event()
    shared_fingers = manager.Value('i', 0)  # Compartilha número de dedos detectados
    shared_expression = manager.Value('i', 0)  # Compartilha expressão
    process = multiprocessing.Process(target=main_loop, args=(window_ready, stop_event, shared_fingers, shared_expression))
    process.start()
    return process, window_ready, stop_event, shared_fingers, shared_expression

def terminate_processes(processes):
    for process in processes:
        if process.is_alive():
            process.terminate()
            process.join()