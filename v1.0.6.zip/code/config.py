# Configuração da tela
SCREEN_WIDTH, SCREEN_HEIGHT = 1280, 720

# Configurações gerais
EXPRESSION = 1
CAMERA = 3

# Cores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
YELLOW = (255, 223, 0)
PINK = (255, 0, 127)

BACKGROUND_COLOR = BLACK

# Arduino
SERIAL_PORT = "COM3"
BAUD_RATE = 9600