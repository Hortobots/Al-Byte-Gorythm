import pygame
import copy
import config

# Posições das barras (atuais e anteriores)
bar_positions = {
    "left_upper": [120, 50, 0],
    "left_lower": [120, 525, 0],
    "right_upper": [755, 50, 0],
    "right_lower": [755, 525, 0]
}

# Deep copy para evitar referências entre listas aninhadas
last_bar_positions = copy.deepcopy(bar_positions)

def doExpressionTransition(screen, delay):
    """ Move as barras suavemente até as novas posições enquanto redesenha a tela """
    global last_bar_positions, bar_positions

    transitioning = True
    while transitioning:
        transitioning = False  # Assume que todas estão na posição correta

        screen.fill(config.BACKGROUND_COLOR)  # Limpa a tela a cada atualização
        
        # Desenha os olhos
        pygame.draw.circle(screen, config.PINK, (config.SCREEN_WIDTH // 4, config.SCREEN_HEIGHT // 2), 150)
        pygame.draw.circle(screen, config.PINK, ((config.SCREEN_WIDTH // 4) * 3, config.SCREEN_HEIGHT // 2), 150)

        for key in bar_positions:
            target_x, target_y, target_angle = bar_positions[key]
            last_x, last_y, last_angle = last_bar_positions[key]

            # Ajuste no eixo X
            if last_x < target_x:
                last_bar_positions[key][0] += min(delay, target_x - last_x)
                transitioning = True
            elif last_x > target_x:
                last_bar_positions[key][0] -= min(delay, last_x - target_x)
                transitioning = True

            # Ajuste no eixo Y
            if last_y < target_y:
                last_bar_positions[key][1] += min(delay, target_y - last_y)
                transitioning = True
            elif last_y > target_y:
                last_bar_positions[key][1] -= min(delay, last_y - target_y)
                transitioning = True

            # Ajuste no ângulo de rotação
            if last_angle < target_angle:
                last_bar_positions[key][2] += min(delay, target_angle - last_angle, 2)  # Limita o incremento
                transitioning = True
            elif last_angle > target_angle:
                last_bar_positions[key][2] -= min(delay, last_angle - target_angle, 2)  # Limita o decremento
                transitioning = True

            # Atualiza a rotação das barras
            angle = last_bar_positions[key][2]
            bar_surface = pygame.Surface((400, 160), pygame.SRCALPHA)
            bar_surface.fill(config.BLACK)
            rotated_bar = pygame.transform.rotate(bar_surface, angle)
            rotated_rect = rotated_bar.get_rect(center=(last_bar_positions[key][0], last_bar_positions[key][1]))
            screen.blit(rotated_bar, rotated_rect.topleft)
        
        pygame.display.update()
        pygame.time.delay(10)  # Pequena pausa para suavizar a animação

def updateScreenExpression(screen, expression, delay):
    """ Desenha a expressão no Pygame """
    global bar_positions

    expressions = {
        1: {
            "left_upper": [320, 125, 0], "right_upper": [955, 125, 0],
            "left_lower": [320, 600, 0], "right_lower": [955, 600, 0]
        },
        2: {
            "left_upper": [320, 250, 0], "right_upper": [955, 250, 0],
            "left_lower": [320, 435, 0], "right_lower": [955, 435, 0]
        },
        3: {
            "left_upper": [320, 250, 0], "right_upper": [955, 250, 0],
            "left_lower": [320, 600, 0], "right_lower": [955, 600, 0]
        },
        4: {
            "left_upper": [320, 250, 0], "right_upper": [955, 125, 0],
            "left_lower": [320, 600, 0], "right_lower": [955, 600, 0]
        },
        5: {
            "left_upper": [320, 125, 0], "right_upper": [955, 250, 0],
            "left_lower": [320, 600, 0], "right_lower": [955, 600, 0]
        },
        6: {
            "left_upper": [320, 220, -20], "right_upper": [955, 220, 20],
            "left_lower": [320, 600, 0], "right_lower": [955, 600, 0]
        },
        7: {
            "left_upper": [320, 220, 20], "right_upper": [955, 220, -20],
            "left_lower": [320, 600, 0], "right_lower": [955, 600, 0]
        }
    }


    if expression not in expressions:
        return

    # Atualiza as posições desejadas das barras
    bar_positions = copy.deepcopy(expressions[expression])
    doExpressionTransition(screen, delay)