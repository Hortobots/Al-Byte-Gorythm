# robot_controller.py
import asyncio
import serial_asyncio
import config

class RobotController:
    def __init__(self):
        self.port = config.SERIAL_PORT
        self.baudrate = config.BAUD_RATE
        self.reader: asyncio.StreamReader = None
        self.writer: asyncio.StreamWriter = None
        self.connected = False

    async def connect(self):
        """
        Abre a conexão serial de forma assíncrona e aguarda o Arduino.
        """
        try:
            self.reader, self.writer = await serial_asyncio.open_serial_connection(
                url=self.port,
                baudrate=self.baudrate
            )
            await asyncio.sleep(2)  # Dá tempo do Arduino reiniciar
            self.connected = True
            print(f"[OK] Conectado em {self.port} @ {self.baudrate}bps")
        except Exception as e:
            print(f"[ERRO] Falha ao conectar na serial: {e}")
            self.connected = False

    async def send_command(self, cmd: str):
        """
        Envia uma linha de comando ao Arduino (com '\n').
        """
        if not self.connected or not self.writer:
            print("[ERRO] Tentando enviar sem conexão ativa.")
            return

        try:
            self.writer.write((cmd + '\n').encode('utf-8'))
            await self.writer.drain()
            print(f"[->] {cmd}")
        except Exception as e:
            print(f"[ERRO] Falha ao enviar comando: {e}")

    async def read_loop(self):
        """
        Lê continuamente as linhas vindas do Arduino.
        """
        if not self.connected:
            print("[WARN] read_loop chamado sem conexão ativa.")
            return

        try:
            while True:
                line = await self.reader.readline()
                if not line:
                    break
                print(f"[<-] {line.decode().strip()}")
        except Exception as e:
            print(f"[ERRO] Falha no read_loop: {e}")

    # Métodos de movimento
    async def move_Fwd(self, speed: int, duration: int):
        await self.send_command(f"move_Fwd {speed} {duration}")

    async def move_Bwd(self, speed: int, duration: int):
        await self.send_command(f"move_Bwd {speed} {duration}")

    async def move_Left(self, speed: int, duration: int):
        await self.send_command(f"move_Left {speed} {duration}")

    async def move_Right(self, speed: int, duration: int):
        await self.send_command(f"move_Right {speed} {duration}")

    async def turnLeft(self, speed: int, degrees: int):
        await self.send_command(f"turnLeft {speed} {degrees}")

    async def turnRight(self, speed: int, degrees: int):
        await self.send_command(f"turnRight {speed} {degrees}")

    async def stop(self):
        await self.send_command("stop")
