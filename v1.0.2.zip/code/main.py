#bibliotecas
import pygame
import cv2 #openCV
import asyncio
import atexit
#import multiprocessing
import sys
from cvzone.HandTrackingModule import HandDetector

#importações locais
import config
from draw_robot_face import updateScreenExpression
from functions import *

# Função para rodar o loop principal do Pygame e OpenCV
#// - Main Loop - ========================================================================================//
def main_loop(window_ready, stop_event, shared_fingers, shared_expression):
    try:
        pygame.init()
        screen = pygame.display.set_mode((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
        pygame.display.set_caption("Hortobots")
        
        cap = cv2.VideoCapture(config.CAMERA)
        fingerDetector = HandDetector(detectionCon=0.8, maxHands=1)
        
        clock = pygame.time.Clock()
        
        window_ready.set()
        
        running = True
        while running:
            success, img = cap.read()
            if success:
                img = cv2.flip(img, 1)
                hands, img = fingerDetector.findHands(img, draw=False)
                
                if hands:
                    hand = hands[0]
                    fingers = fingerDetector.fingersUp(hand)
                    shared_fingers.value = sum(fingers)  # Atualiza número de dedos levantados
                else:
                    shared_fingers.value = 0  # Se nenhuma mão for detectada, zera
                
            updateScreenExpression(screen, shared_expression.value, 20)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT or pygame.mouse.get_pressed()[0]:
                    running = False
                    stop_event.set()
                    break
            
            clock.tick(60)
    except Exception as e:
        print(f"Erro no loop da câmera: {e}")
    finally:
        cap.release()
        cv2.destroyAllWindows()
        pygame.quit()


#// - setup - ========================================================================================//
async def setup(window_ready, stop_event, shared_fingers, shared_expression):
    print("Aguardando janela abrir...")
    window_ready.wait()
    print("Janela aberta! Iniciando sequência...")
    
    if stop_event.is_set():
        print("Encerrando setup...")
        return
    shared_expression.value = config.EXPRESSION

    await waitToFingersUp(2, shared_fingers, stop_event)
    shared_expression.value = 2
    await asyncio.sleep(1)
    await waitToFingersUp(3, shared_fingers, stop_event)
    shared_expression.value = 3
    await asyncio.sleep(1)
    await waitToFingersUp(4, shared_fingers, stop_event)
    shared_expression.value = 4
    await asyncio.sleep(1)
    await waitToFingersUp(2, shared_fingers, stop_event)
    shared_expression.value = 2
    await asyncio.sleep(5)

#// - Main - ========================================================================================//
if __name__ == "__main__":
    try:
        process, window_ready, stop_event, shared_fingers, shared_expression = start_multi_process()
        atexit.register(lambda: terminate_processes([process]))
        asyncio.run(setup(window_ready, stop_event, shared_fingers, shared_expression))
    except KeyboardInterrupt:
        print("Encerrando o programa...")
    except Exception as e:
        print(f"Erro inesperado: {e}")
    finally:
        terminate_processes([process])
        print("Processo finalizado com sucesso!")
        sys.exit(0)
